import Erdos1135.Terras.Density.NaturalDensity

/-!
# Lightweight natural-counting core for ND-3.1

These definitions are factored out of `ND.Conventions` so the fixed-target
statement and the logical fusion theorem do not import the probability layer.
Their bodies are unchanged from the pinned `ca3dd0d...` source package.
-/

namespace Erdos1135
namespace ND

/-- Inclusive natural count `#(S ∩ [0,X])`.

The inherited `natCount S K` counts the half-open prefix `[0,K)`, hence the
explicit successor. -/
noncomputable def natCountLE (S : Set ℕ) (X : ℕ) : ℕ :=
  Terras.natCount S (X + 1)

/-- Inclusive real-endpoint count, with endpoint `floor x`. -/
noncomputable def natCountLEReal (S : Set ℕ) (x : ℝ) : ℕ :=
  natCountLE S (Nat.floor x)

end ND
end Erdos1135
