import Erdos1135.Orbit
import Mathlib.Data.Finset.Interval

/-
Local addition notice (2026-07-24): this finite-certificate module was added
by the local weak-fusion extension. It is not presented as part of the pinned
ca3 upstream package.
-/

/-!
# Decidable finite-base certificates

This module turns a finite, bounded computation into the mathematical
hypothesis needed by the parametric density fusion. Both quantifiers in
`FiniteBaseVerified N0 T` are finite, so the proposition is decidable.
-/

namespace Erdos1135
namespace ND

/-- The raw Collatz orbit of `n` reaches `1` in at most `T` steps. -/
def ReachesOneWithin (T n : ℕ) : Prop :=
  ∃ m ∈ Finset.range (T + 1), (collatzStep^[m]) n = 1

instance (T n : ℕ) : Decidable (ReachesOneWithin T n) := by
  unfold ReachesOneWithin
  exact Finset.decidableExistsAndFinset

/-- A decidable certificate for every positive input at most `N0`, using a
common search bound `T` for the number of raw Collatz steps. -/
def FiniteBaseVerified (N0 T : ℕ) : Prop :=
  ∀ n ∈ Finset.Icc 1 N0, ReachesOneWithin T n

instance (N0 T : ℕ) : Decidable (FiniteBaseVerified N0 T) := by
  unfold FiniteBaseVerified
  exact Finset.decidableDforallFinset

theorem reachesOne_of_reachesOneWithin {T n : ℕ}
    (h : ReachesOneWithin T n) : Reaches n 1 := by
  rcases h with ⟨m, _hm, hiterate⟩
  exact ⟨m, hiterate⟩

/-- Soundness of the executable finite-base certificate. The positivity
hypothesis is essential because the raw Collatz orbit of `0` does not reach
`1`. -/
theorem finiteBase_of_verified {N0 T : ℕ}
    (h : FiniteBaseVerified N0 T) :
    ∀ n : ℕ, 0 < n → n ≤ N0 → Reaches n 1 := by
  intro n hnpos hnN0
  apply reachesOne_of_reachesOneWithin
  exact h n (Finset.mem_Icc.mpr ⟨hnpos, hnN0⟩)

end ND
end Erdos1135
