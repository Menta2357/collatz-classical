import Erdos1135.ND.StatementCore
import Erdos1135.ND.FiniteBaseCertificate
import Erdos1135.Tao.Syracuse.CollatzBridge

/-
Local addition notice (2026-07-24): this parametric fusion module was added by
the local weak-fusion extension. It is not presented as part of the pinned ca3
upstream package.
-/

/-!
# Parametric fixed-target fusion

The direct API consumes a fixed bad-ratio bound `q < 1/2`. The ND-3.1 API is a
separate adapter which specializes `q` to its chosen prefactor expression.
The conclusion is an ambient eventual positive lower bound for raw Collatz
reachability. It does not assert existence of a natural-density limit.
-/

namespace Erdos1135
namespace ND

open Filter
open scoped Topology

noncomputable section

/-- Positive lower natural density in the weak, explicit sense needed here. -/
def HasPositiveLowerNatDensity (S : Set ℕ) : Prop :=
  ∃ δ : ℝ, 0 < δ ∧
    ∀ᶠ X : ℕ in atTop, δ ≤ Terras.natCountingRatio S X

/-- Naturals whose raw Collatz orbit reaches `1`. -/
def collatzReachesOneSet : Set ℕ :=
  {N : ℕ | Reaches N 1}

/-- Explicit margin reserved from the ambient odd mass `1/2`. -/
def fixedTargetDelta (q : ℝ) : ℝ :=
  ((1 / 2 : ℝ) - q) / 2

theorem fixedTargetDelta_pos {q : ℝ} (hq : q < (1 / 2 : ℝ)) :
    0 < fixedTargetDelta q := by
  unfold fixedTargetDelta
  linarith

private theorem natCount_le_natCountLEReal_natCast_fusion
    (S : Set ℕ) (N : ℕ) :
    Terras.natCount S N ≤ natCountLEReal S (N : ℝ) := by
  unfold natCountLEReal natCountLE Terras.natCount
  simp only [Nat.floor_natCast]
  rw [Nat.count_succ]
  split <;> omega

private theorem natCountingRatio_bad_le_oddBadRatio
    (N0 X : ℕ) (hX : 0 < X) :
    Terras.natCountingRatio (oddSyracuseBadSet N0) X ≤
      oddSyracuseBadRatio N0 (X : ℝ) := by
  have hcount :
      (Terras.natCount (oddSyracuseBadSet N0) X : ℝ) ≤
        (natCountLEReal (oddSyracuseBadSet N0) (X : ℝ) : ℝ) := by
    exact_mod_cast
      natCount_le_natCountLEReal_natCast_fusion
        (oddSyracuseBadSet N0) X
  have hXnonneg : (0 : ℝ) ≤ (X : ℝ) := by positivity
  exact div_le_div_of_nonneg_right hcount hXnonneg

private theorem syracuse_iterate_pos {N : ℕ} (hN : 0 < N) (m : ℕ) :
    0 < (Tao.syracuse^[m]) N := by
  induction m generalizing N with
  | zero => simpa
  | succ m ih =>
      rw [Function.iterate_succ_apply]
      exact ih (Tao.syracuse_pos N)

private theorem oddHitAtMost_subset_reachesOne
    {N0 : ℕ}
    (hfinite : ∀ n : ℕ, 0 < n → n ≤ N0 → Reaches n 1) :
    {N : ℕ | 0 < N ∧ Odd N ∧ Tao.syracuseHitsAtMost N N0} ⊆
      collatzReachesOneSet := by
  intro N hN
  rcases hN.2.2 with ⟨m, hm⟩
  exact (Tao.reaches_syracuse_iterate hN.2.1 m).trans
    (hfinite ((Tao.syracuse^[m]) N)
      (syracuse_iterate_pos hN.1 m) hm)

/-- Direct fixed-target theorem with an explicit eventual lower bound. -/
theorem fusion_eventual_lower_bound_of_bad_ratio
    {q : ℝ} {N0 : ℕ}
    (hbound : ∀ x : ℝ, 2 ≤ x → oddSyracuseBadRatio N0 x ≤ q)
    (hsmall : q < (1 / 2 : ℝ))
    (hfinite : ∀ n : ℕ, 0 < n → n ≤ N0 → Reaches n 1) :
    ∀ᶠ X : ℕ in atTop,
      fixedTargetDelta q ≤
        Terras.natCountingRatio collatzReachesOneSet X := by
  let good : Set ℕ :=
    {N : ℕ | 0 < N ∧ Odd N ∧ Tao.syracuseHitsAtMost N N0}
  let odds : Set ℕ := {N : ℕ | Odd N}
  have hpartition : odds = good ∪ oddSyracuseBadSet N0 := by
    ext N
    simp only [odds, good, oddSyracuseBadSet, Set.mem_setOf_eq,
      Set.mem_union]
    constructor
    · intro hOdd
      have hpos : 0 < N := Odd.pos hOdd
      by_cases hhit : Tao.syracuseHitsAtMost N N0
      · exact Or.inl ⟨hpos, hOdd, hhit⟩
      · exact Or.inr ⟨hpos, hOdd, hhit⟩
    · rintro (hgood | hbad)
      · exact hgood.2.1
      · exact hbad.2.1
  have hdisj : Disjoint good (oddSyracuseBadSet N0) := by
    rw [Set.disjoint_left]
    intro N hgood hbad
    exact hbad.2.2 hgood.2.2
  have hOddDensity : Terras.HasNatDensity odds (1 / 2 : ℝ) := by
    simpa only [odds, Nat.odd_iff, Nat.ModEq] using
      (Terras.hasNatDensity_modEq
        (m := 2) (by norm_num : 0 < 2) 1)
  have hthreshold : (q + (1 / 2 : ℝ)) / 2 < (1 / 2 : ℝ) := by
    linarith
  have hOddsEventually :
      ∀ᶠ X : ℕ in atTop,
        (q + (1 / 2 : ℝ)) / 2 < Terras.natCountingRatio odds X :=
    (tendsto_order.1 hOddDensity).1 _ hthreshold
  have hLarge : ∀ᶠ X : ℕ in atTop, 2 ≤ X :=
    eventually_atTop.2 ⟨2, fun _ h => h⟩
  have hGoodEventually :
      ∀ᶠ X : ℕ in atTop,
        fixedTargetDelta q ≤ Terras.natCountingRatio good X := by
    filter_upwards [hOddsEventually, hLarge] with X hOdds hX
    have hXpos : 0 < X := lt_of_lt_of_le (by norm_num) hX
    have hBadRatio :
        Terras.natCountingRatio (oddSyracuseBadSet N0) X ≤ q := by
      exact (natCountingRatio_bad_le_oddBadRatio N0 X hXpos).trans
        (hbound (X : ℝ) (by exact_mod_cast hX))
    have hcount := Terras.natCount_union_of_disjoint hdisj X
    have hratio :
        Terras.natCountingRatio odds X =
          Terras.natCountingRatio good X +
            Terras.natCountingRatio (oddSyracuseBadSet N0) X := by
      rw [hpartition, Terras.natCountingRatio,
        Terras.natCountingRatio, Terras.natCountingRatio, hcount,
        Nat.cast_add]
      ring
    unfold fixedTargetDelta
    linarith
  have hsubset : good ⊆ collatzReachesOneSet :=
    oddHitAtMost_subset_reachesOne hfinite
  have hmono := Terras.natCountingRatio_mono_eventually hsubset
  filter_upwards [hGoodEventually, hmono] with X hgood hle
  exact hgood.trans hle

/-- Direct fixed-target theorem packaged as positive lower natural density. -/
theorem fusion_of_bad_ratio_bound
    {q : ℝ} {N0 : ℕ}
    (hbound : ∀ x : ℝ, 2 ≤ x → oddSyracuseBadRatio N0 x ≤ q)
    (hsmall : q < (1 / 2 : ℝ))
    (hfinite : ∀ n : ℕ, 0 < n → n ≤ N0 → Reaches n 1) :
    HasPositiveLowerNatDensity collatzReachesOneSet := by
  exact ⟨fixedTargetDelta q, fixedTargetDelta_pos hsmall,
    fusion_eventual_lower_bound_of_bad_ratio hbound hsmall hfinite⟩

/-- Formula-facing API with the lower bound visible in the conclusion. -/
theorem fusion_eventual_lower_bound_of_density_bound
    {d C_d : ℝ} {N0 : ℕ}
    (hbound : ∀ x : ℝ, 2 ≤ x →
      oddSyracuseBadRatio N0 x ≤
        C_d * Real.rpow (Real.log (N0 : ℝ)) (-d))
    (hsmall :
      C_d * Real.rpow (Real.log (N0 : ℝ)) (-d) < (1 / 2 : ℝ))
    (hfinite : ∀ n : ℕ, 0 < n → n ≤ N0 → Reaches n 1) :
    ∀ᶠ X : ℕ in atTop,
      fixedTargetDelta
          (C_d * Real.rpow (Real.log (N0 : ℝ)) (-d)) ≤
        Terras.natCountingRatio collatzReachesOneSet X := by
  exact fusion_eventual_lower_bound_of_bad_ratio hbound hsmall hfinite

/-- Parametric fusion of a fixed-target density formula and a finite base. -/
theorem fusion_of_density_bound
    {d C_d : ℝ} {N0 : ℕ}
    (_hN0 : 2 ≤ N0)
    (hbound : ∀ x : ℝ, 2 ≤ x →
      oddSyracuseBadRatio N0 x ≤
        C_d * Real.rpow (Real.log (N0 : ℝ)) (-d))
    (hsmall :
      C_d * Real.rpow (Real.log (N0 : ℝ)) (-d) < (1 / 2 : ℝ))
    (hfinite : ∀ n : ℕ, 0 < n → n ≤ N0 → Reaches n 1) :
    HasPositiveLowerNatDensity collatzReachesOneSet := by
  exact fusion_of_bad_ratio_bound hbound hsmall hfinite

/-- The ND-3.1 adapter with its explicit eventual lower-bound witness. -/
theorem fusion_eventual_lower_bound_of_nd31Bounds
    {d : ℝ} (h31 : ND31Bounds d)
    {N0 : ℕ} (hN0 : 2 ≤ N0)
    (hsmall :
      h31.choose * Real.rpow (Real.log (N0 : ℝ)) (-d) < (1 / 2 : ℝ))
    (hfinite : ∀ n : ℕ, 0 < n → n ≤ N0 → Reaches n 1) :
    ∀ᶠ X : ℕ in atTop,
      fixedTargetDelta
          (h31.choose * Real.rpow (Real.log (N0 : ℝ)) (-d)) ≤
        Terras.natCountingRatio collatzReachesOneSet X := by
  exact fusion_eventual_lower_bound_of_density_bound
    (fun x hx => h31.choose_spec.2 N0 x hN0 hx) hsmall hfinite

/-- The existential ND-3.1 package yields positive lower natural density once
its chosen witness passes the strict fixed-target gate. -/
theorem fusion_of_nd31Bounds
    {d : ℝ} (h31 : ND31Bounds d)
    {N0 : ℕ} (hN0 : 2 ≤ N0)
    (hsmall :
      h31.choose * Real.rpow (Real.log (N0 : ℝ)) (-d) < (1 / 2 : ℝ))
    (hfinite : ∀ n : ℕ, 0 < n → n ≤ N0 → Reaches n 1) :
    HasPositiveLowerNatDensity collatzReachesOneSet := by
  exact fusion_of_density_bound hN0
    (fun x hx => h31.choose_spec.2 N0 x hN0 hx) hsmall hfinite

/-- End-to-end ND-3.1 adapter with a decidable finite certificate and explicit
eventual lower bound. -/
theorem fusion_eventual_lower_bound_of_nd31Bounds_of_finiteBaseVerified
    {d : ℝ} (h31 : ND31Bounds d)
    {N0 T : ℕ} (hN0 : 2 ≤ N0)
    (hsmall :
      h31.choose * Real.rpow (Real.log (N0 : ℝ)) (-d) < (1 / 2 : ℝ))
    (hfinite : FiniteBaseVerified N0 T) :
    ∀ᶠ X : ℕ in atTop,
      fixedTargetDelta
          (h31.choose * Real.rpow (Real.log (N0 : ℝ)) (-d)) ≤
        Terras.natCountingRatio collatzReachesOneSet X := by
  exact fusion_eventual_lower_bound_of_nd31Bounds h31 hN0 hsmall
    (finiteBase_of_verified hfinite)

/-- End-to-end ND-3.1 adapter packaged as positive lower natural density. -/
theorem fusion_of_nd31Bounds_of_finiteBaseVerified
    {d : ℝ} (h31 : ND31Bounds d)
    {N0 T : ℕ} (hN0 : 2 ≤ N0)
    (hsmall :
      h31.choose * Real.rpow (Real.log (N0 : ℝ)) (-d) < (1 / 2 : ℝ))
    (hfinite : FiniteBaseVerified N0 T) :
    HasPositiveLowerNatDensity collatzReachesOneSet := by
  exact fusion_of_nd31Bounds h31 hN0 hsmall
    (finiteBase_of_verified hfinite)

end

end ND
end Erdos1135
