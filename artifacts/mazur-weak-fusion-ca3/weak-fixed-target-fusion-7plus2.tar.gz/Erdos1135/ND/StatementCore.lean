import Erdos1135.ND.CountingCore
import Erdos1135.Tao.Syracuse.Defs
import Mathlib.Analysis.SpecialFunctions.Pow.Real

/-
Modification notice (2026-07-24): this local derivative factors the fixed-
target ND-3.1 definitions out of `Erdos1135/ND/Statement.lean` from the pinned
ca3 package. Their definition bodies are unchanged; the pinned upstream
package itself was not modified.
-/

/-!
# Lightweight fixed-target ND-3.1 statement core

This file contains the public ND-3.1 definitions factored out of
`ND.Statement` without changing their bodies from the pinned `ca3dd0d...`
source package.
-/

namespace Erdos1135
namespace ND

/-- Positive odd inputs whose Syracuse orbit minimum is above `N0`. -/
def oddSyracuseBadSet (N0 : ℕ) : Set ℕ :=
  {N : ℕ | 0 < N ∧ Odd N ∧ ¬ Tao.syracuseHitsAtMost N N0}

/-- The natural-endpoint specialization of the ND-3.1 bad ratio. -/
noncomputable def oddSyracuseBadRatioNat (N0 X : ℕ) : ℝ :=
  (natCountLE (oddSyracuseBadSet N0) X : ℝ) / (X : ℝ)

/-- The exact real-endpoint ND-3.1 bad ratio. The numerator counts the
inclusive interval `[1,floor x]`; the odd guard removes zero. -/
noncomputable def oddSyracuseBadRatio (N0 : ℕ) (x : ℝ) : ℝ :=
  (natCountLEReal (oddSyracuseBadSet N0) x : ℝ) / x

/-- ND-3.1 at a fixed logarithmic exponent `c`.

Both `N0 ≥ 2` and the positive real counting endpoint `x ≥ 2` remain
visible. -/
def ND31Bounds (c : ℝ) : Prop :=
  ∃ C : ℝ, 0 ≤ C ∧
    ∀ (N0 : ℕ) (x : ℝ), 2 ≤ N0 → 2 ≤ x →
      oddSyracuseBadRatio N0 x ≤
        C * Real.rpow (Real.log (N0 : ℝ)) (-c)

end ND
end Erdos1135
