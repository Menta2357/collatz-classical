import Mathlib.Algebra.Ring.Parity

/-!
# Lightweight canonical Collatz step

This is the definition-only fragment of
`FormalConjectures.Wikipedia.CollatzConjecture`. The omitted open conjecture
and its editorial attributes are irrelevant to the parametric fusion
interface.
-/

namespace CollatzConjecture

/-- The canonical raw Collatz step used by the checked Erdos1135 sources. -/
def collatzStep (n : ℕ) : ℕ :=
  if Even n then n / 2 else 3 * n + 1

end CollatzConjecture
