/-
Copyright 2025 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

/-
Modification notice (2026-07-24): this local derivative extracts only the
raw Collatz-step definition from
`FormalConjectures/Wikipedia/CollatzConjecture.lean` so the weak-fusion route
does not import the open conjecture theorem. The pinned upstream source file
itself was not modified.
-/

import Mathlib.Algebra.Ring.Parity

/-!
# Lightweight canonical Collatz step

This is the definition-only fragment of
`FormalConjectures.Wikipedia.CollatzConjecture`. The omitted open conjecture
and its editorial attributes are irrelevant to the parametric fusion
interface.
-/

namespace CollatzConjecture

/-- The canonical raw Collatz step used by the checked Erdos1135 sources. -/
def collatzStep (n : ℕ) : ℕ :=
  if Even n then n / 2 else 3 * n + 1

end CollatzConjecture
