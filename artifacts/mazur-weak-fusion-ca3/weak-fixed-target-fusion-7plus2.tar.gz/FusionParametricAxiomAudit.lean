/-
Local addition notice (2026-07-24): this axiom-audit entry point was added by
the local weak-fusion extension. It is not presented as part of the pinned ca3
upstream package.
-/

import Erdos1135.ND.FusionParametric

#print axioms Erdos1135.ND.reachesOne_of_reachesOneWithin
#print axioms Erdos1135.ND.finiteBase_of_verified
#print axioms Erdos1135.ND.fixedTargetDelta_pos
#print axioms Erdos1135.ND.fusion_eventual_lower_bound_of_bad_ratio
#print axioms Erdos1135.ND.fusion_of_bad_ratio_bound
#print axioms Erdos1135.ND.fusion_eventual_lower_bound_of_density_bound
#print axioms Erdos1135.ND.fusion_of_density_bound
#print axioms Erdos1135.ND.fusion_eventual_lower_bound_of_nd31Bounds
#print axioms Erdos1135.ND.fusion_of_nd31Bounds
#print axioms
  Erdos1135.ND.fusion_eventual_lower_bound_of_nd31Bounds_of_finiteBaseVerified
#print axioms Erdos1135.ND.fusion_of_nd31Bounds_of_finiteBaseVerified
#print axioms Erdos1135.Tao.reaches_syracuse_iterate
